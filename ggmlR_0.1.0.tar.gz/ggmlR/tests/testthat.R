library(testthat)
library(ggmlR)

test_check("ggmlR")
